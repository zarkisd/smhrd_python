#!/usr/bin/env python
# coding: utf-8

# In[1]:


def sum(a,b):
    return a+b


# In[2]:





# In[ ]:




