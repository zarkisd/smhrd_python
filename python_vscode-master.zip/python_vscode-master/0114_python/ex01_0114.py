print("당신의 이름을 입력하세요")
name=input()
print("당신의 이름은",name,"입니다")

num1=int(input("첫번째 정수 입력 : "))
num2=int(input("두번째 정수 입력 : "))

print(num1,"과",num2,"의 합은",num1+num2, "입니다")
print('{}과 {}의 합은 {}입니다'.format(num1,num2,num1+num2))

num1 = int(input('첫 번째 정수 입력'))
num2 = int(input('두 번째 정수 입력'))
# num1 = 10, num2 = 3
print('나눗셈 몫 : {}'.format(num1 // num2)) # 3
print('나머지 : {}'.format(num1 % num2)) # 1

sec=int(input("초 입력"))
hour=sec//60//60
min=(sec-hour*60*60)//60
sec=sec-hour*60*60-min*60
print("{}시 {}분 {}초".format(hour, min, sec))

a = []
b = [1, 2, 3]
c = ['Life', 'is', 'too', 'short']
d = [1, 2, 'Life', 'is']
e = [1, 2, ['Life', 'is']]

# 리스트명[인덱스]--->인덱싱
print(b[1])
print(e[2][0])
#슬라이싱 요소1 :  요소2  ---> 요소1부터 요소 2 앞까지
print(c[:2])
print(c[0:2])


list2=[10,40,50,34,30,20,26,90]
#50부터 20까지 요소 출력
print(list2[2:6])
#10부터 30까지
print(list2[:5])
#34부터 끝까지
print(list2[3:])


list3=["소고기짬뽕", "치킨", "낙지덮밥", "얼큰수제비", "불족발", "랍스터"]
print(list3[-1])
#얼큰 수제비부터 뒤에서 두번째 음식 출력
print(list3[-3:-1])

array=[1,2,3,['a','b','c'],4,5]
#3 ['a','b','c'],4 출력
print(array[2:5])
#['a','b']만 출력
print(array[3][:2])


#Python is very easy
str2="Python is very easy"
print(str2)
#phthon is very easy he said. 출력
#str3 출력
str3="'Python is very easy.' he said."
str4='\'Python is very easy.\' he said'
str5="""'Python is very easy.' he said."""
print(str3)
print(str4)
print(str5)
# \n 쓰거나 엔터치고 """ 넣기
# \t 탭
# tab 자동완성 
multiline="Life is too short. \n\tYou need Python."
print(multiline)

# dictionary

dic={"name":"나예호", "age":21, "tel":"010-3197-4771"}
print(dic)
# name이라는 key값에 해당하는 value
print(dic.get("name"))
print(dic["name"])
print(dic.get("tel"))
dic["addr"]="광주 북구 각화동"
print(dic)

# dic 키값만 출력
print(dic.keys())
print(list(dic.keys()))
# dic 밸류값만 출력
print(dic.values())
# dic 튜플형태로 출력
print(dic.items())

# key in 딕셔너리명
# True or False
print("name" in dic)
print("birth" in dic)

# addr 키값 삭제
del dic["addr"]
print(dic)














