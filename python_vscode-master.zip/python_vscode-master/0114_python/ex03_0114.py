def sum(a,b):
    return a+b

print(sum(3,10))

#import exam_03_copy
#result=int(exam_03_copy.sum(10,19))
#print(result)

#import exam_03_copy as ex
#result=int(ex.sum(10,19))
#print(result)
