score= int(input("점수를 입력하세요 : "))

#90이상 이라면 A학점
if score>=90:
    print("A학점")
elif score>=80:
    print("B학점")
elif score>=70:
    print("C학점")
elif score>=60:
    print("D학점")
else:
    print("F학점")

i=0
while i<10:
    print(i, end=' ')
    i+=1

j=0

while True:
    print(j, end=" ")
    j+=1
    if j==10:
        break

# for 변수 in 리스트, 튜플, 문자열
array=[1,2,3,4,5]
for i in array:
    print(i, end=" ")

name="나예호"
for i in name:
    print(i)

# 1~10까지 for문 이용해서 출력
# range(시작값, 끝값, 증가량)
for i in range(1,11,1):
    print(i, end=" ")

print()
for i in range(1,11):
    print(i, end=" ")
    
print()
for i in range(11):
    if i==0:
        continue
    print(i, end=" ")

#배수 출력 프로그램
num=int(input("정수 입력 : "))
for i in range(1,11):
    print(num*i, end=" ")

name="손준호"

print(name*3)

for i in range(1,6):
    print("*"*i)




    











