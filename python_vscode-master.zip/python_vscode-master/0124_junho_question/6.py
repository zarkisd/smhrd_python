#간단한 재귀함수 문제 
# 팰린드롬이란 앞으로 읽을 때와 거꾸로 읽을 때 똑같은 단어를 말한다.
# 알파벳 소문자로만 이루어진 단어가 주어진다. 
# 이때, 이 단어가 팰린드롬인지 아닌지 확인하는 프로그램을 작성하시오.
# level, noon은 팰린드롬이고, baekjoon, online, judge는 팰린드롬이 아니다.
# 재귀함수로 안풀어도 된다

 


def is_palindrome(word):                           
    if len(word) < 2:
        return True
    if word[0] != word[-1]:
        return False
    return is_palindrome(word[1:-1])
                                    
print(is_palindrome('hello'))#False
print(is_palindrome('level'))#True


#2 재귀함수로 안푼방법
def palindrome(t_str):
    for i in range(len(t_str)):
        if t_str[i] != t_str[len(t_str)-1-i]:
            return False
    return True
 
t_str = input()
print(t_str)
if palindrome(t_str):
   print("입력하신 단어는 회문(Palindrome)입니다.")
else :
   print("입력하신 단어는 회문(Palindrome)이 아닙니다.")