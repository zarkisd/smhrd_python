# 다음의 결과와 같이 구구단 2단부터 9단의 결과값 중에 3의 배수거나 7의 배수인 수를

# 제외한 값을 리스트 객체 result 안에 각 단마다 리스트를 만들어 삽입하고 이를 출력하십시오.


result_list = []
for i in range(2, 10):
   temp_list = []
   for j in range(1, 10):
      t = i*j
      #3의 배수이거나 7의 배수라면 continue
      if not (t % 3) or not (t % 7):
         continue
      temp_list.append(t)
   result_list.append(temp_list)
print(result_list)


# 포매팅 문제
# 트리 모양 만드세요
for i in range(1,20+1):
    print('{:^30}'.format('*' * i))

# 1~9 사이의 정수 a를 입력받아 
# a + aa + aaa + aaaa 의 값을 계산하는 프로그램을 작성하십시오.

a = int(input()) 
t = 0   #배수계산
s = 0   #합
for i in range(1, 5): #1부터 4까지 반복
    t = t*10 + 1   #1, 11, 111, 1111 만듬
    s += a*t    # a + aa+ aaa+ aaaa 를 한다.
print(s)    #결과값 출력

#10진수를 2진수로 출력하는 프로그램
a = int(input())

print(format(a, 'b'))


#인자로 전달된 숫자를 이용해 카운트다운하는 함수 countdown을 정의하고,
#이 함수를 이용하여 countdown(0), countdown(10)을 순서대로 실행하십시오.
# 0보다 작거나 같은 인자가 전달되었을 경우 "카운트다운을 하려면 0보다 큰 입력이 필요합니다."를 출력하십시오.

def countdown(k):
    if k <=0:
        print("카운트다운을 하려면 0보다 큰 입력이 필요합니다.")
    for i in range(k, 0, -1):
        print(i)    
 
countdown(0)
countdown(10)



# enumerate
#- student라는 list에 손준호, 오유정, 오경민, 장현석, 김민희, 도한재 입력하고
#- enumerate를 사용해 각각 이름에 순서를 넣어주는 프로그램 만들어주세요


students=["손준호", "오유정", "오경민", "장현석", "김민희", "도한재"]
for number, name in enumerate(students):
    print("번호 : {0}, 이름 : {1}".format(number+1,name))



# numpy 모듈을 사용하여 
# 1. 10~49까지의 수를 가지고 있는 리스트를 출력하세요
# 2. 역으로 출력하세요

import numpy as np
x=np.arange(10,49+1)
print(x)
print(x[::-1])