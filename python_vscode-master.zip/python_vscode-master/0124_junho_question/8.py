#에라토스테네스의체
# 1000까지의 소수의 개수를 구하시오
# 문제 폐기


#1
number=1000
list=[]
count=0
def primeNumberService():
    #리스트에 담기
    for i in range(2,number+1):
        list.insert(i-2,i)
    # 배수인거 다 0으로 해주기
    for i in range(2,number+1):
        if list[i-2]==0:
            continue
        #이부분 다 0으로
        for j in range(2*i, number+1, i):
            list[j-2]=0
            
    for i in range(2,number+1):
        if list[i-2]!=0:
            print(f"{list[i-2]}")
            global count
            count+=1
      
primeNumberService()
print(list)
print(count)

#2
count1=0
primes=[]
for i in range(2,1000):
    is_prime=True
    for j in range(2,i):
        if i%j ==0:
            is_prime=False
    if is_prime==True:
        primes= primes + [i]
        count1+=1

print(primes)
print(count1)

