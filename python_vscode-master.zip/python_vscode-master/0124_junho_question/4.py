# 리스트 내포 기능을 이용해 다음 문장으로부터 모음('aeiou')을 제거하십시오.
# 책에 있는 리스트 내포 사용 
# 굳이 안해도 되는데 남의 코드 볼때 모르면 안되니까
# 또한 가독성 좋다
#Python is powerful... and fast; plays well with others; runs everywhere; is friendly & easy to learn; is Open.



#data_str="Python is powerful... and fast; plays well with others; runs everywhere; is friendly & easy to learn; is Open."
# serch = "aeiou"
# result = [i for i in data_str if i not in serch]
# print("".join(result))