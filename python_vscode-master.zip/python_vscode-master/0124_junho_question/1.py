# 홀만 출력하세요
string="홀짝홀짝홀짝홀짝홀짝"





print(string[::2])
