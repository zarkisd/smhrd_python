list_a=[0,1,2,3,4,5,6,7]

list_a.extend(list_a)
list_a.append(10)
list_a.insert(3,0)
list_a.remove(3)
list_a.pop(3)
#list_a.clear
print(list_a)

numbers=[273,103,5,32,65,9,72,800,99]
for number in numbers:
    if number > 100:
        print(f"- 100 이상의 수 : {number}")

for number in numbers:
    if number%2==0:
        print(f"{number}는 짝수입니다.")
    else:
        print(f"{number}는 홀수입니다.")

import math
for number in numbers:
    #로그사용해서 자릿수 구하기
    if int(math.log10(number))+1 == 1:
        print(f"{number}는 1자릿수입니다.")
    elif int(math.log10(number))+1 == 2:
        print(f"{number}는 2자릿수입니다.")
    else:
        print(f"{number}는 3자릿수입니다.")


list_of_list=[[1,2,3],[4,5,6,7],[8,9]]
for first in list_of_list:
    for index in first:
        print(index)



numbers=[1,2,3,4,5,6,7,8,9]
output=[[],[],[]]

for number in numbers:
    output[(number-1)%3].append(number)

print(output)