array=[273,32,103,57,52]

for element in array:
    print(element)