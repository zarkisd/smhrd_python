dictionary={
    "name":"7D 건조 망고",
    "type":"당절임"
  
}
  
print("요소 제거 이전 : ",dictionary)
del dictionary["name"]
del dictionary["type"]
print()
print("요소 제거 이전 : ",dictionary)