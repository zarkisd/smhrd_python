x=10
under_20=x<20
print("under_20 :",under_20)
print("not under_20 : ", not under_20)


number=input("정수 입력 > ")
number=int(number)

if number>0:
    print("+")
elif number<0:
    print("-")
else:
    print("0")