# count=0
# while True:
#     print(".",end="")
#     count+=1
#     if count==150:
#         break

i=0
while i<10:
    print(f"{i}번째 반복입니다.")
    i+=1

list_test=[1,2,1,2]
value=2
while value in list_test:
    list_test.remove(value)
print(list_test)

#통신할때 사용
# import time
# number=0
# target_tick=time.time()+1
# while time.time() < target_tick:
#     number+=1
# print(f"1초 동안 {number}반복했습니다.")

i=0
while True:
    print(f"{i}번째 반복문입니다.")
    i+=1
    input_text=input("종료하시겠습니까?")
    if input_text in ["y","Y"]:
        print("반복을 종료합니다.")
        break

numbers=[5,15,6,20,7,25]
for number in numbers:
    if number<10:
        continue
    print(number)