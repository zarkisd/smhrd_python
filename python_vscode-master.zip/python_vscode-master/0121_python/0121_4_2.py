# 1
dict_a = {}
dict_a["name"] = "구름"
dict_b = {"name": "구름"}
del dict_b["name"]
print(dict_a)
print(dict_b)
# 2
pets = [{"name": "구름", "age": 5}, {"name": "초코", "age": 3},
        {"name": "아지", "age": 1}, {"name": "호랑이", "age": 1}]
print("# 우리 동네 애완 동물들")
for dic in pets:
    print(f"{dic['name']} {dic['age']}살")
#3
#랜덤 난수 생성
import random
numbers=[]
for i in range(1,21):
    i=random.randrange(1,10)
    numbers.append(i)
print(numbers)
counter={}
for number in numbers:
    # 있으면 value+1 해주고
    if number in counter:
        counter[number]=counter[number]+1
    #첫번째는 카운터에 없으니까 1 해주고
    #그다음부터 나온 숫자가 또 없으면 1하나 생성해주고
    else:
        counter[number]=1
print(counter)
#4
character={
    "name":"기사",
    "level":12,
    "items":{
        "sword":"불꽃의 검",
        "armor":"풀플레이트"
    },
    "skill":["베기", "세게 베기", "아주 세게 베기"]
}
print()

for key in character:
    if type(character[key]) is str:
        print(f"{key} : {character[key]}")
    elif type(character[key]) is list:
        for i in character[key]:
             print(f"{key} : {i}")
    elif type(character[key]) is dict:
        for i in character[key]:
            #i 는 sword, armor다
            # character[key]=items
            # items[sword]=불꽃의검
            print(f"{i} : {character[key][i]}")
    else:
        print(f"{key} : {character[key]}")
