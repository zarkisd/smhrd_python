a=input("문자열 입력 > ")
b=input("문자열 입력 > ")
print(a,b)
#튜플
#자리바꾸기
c=a
a=b
b=c
print(a,b)