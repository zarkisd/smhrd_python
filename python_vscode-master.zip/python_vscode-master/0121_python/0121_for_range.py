for i in range(5):
    print(f"{str(i)}=반복변수")
print()
for i in range(5,10):
    print(f"{str(i)}=반복변수")
print()
for i in range(0,10,3):
    print(f"{str(i)}=반복변수")
print()
#list_range01.py
#가장 많이 사용
array=[273,32,103,57,52]
for i in range(len(array)):
    print(f"{i}번째 반복 : {array[i]}")
#reversed_for01.py
print()
for i in range(4,0-1,-1):
    print(f"현재 반복 변수 : {i}")
print()
for i in reversed(range(5)):
    print(f"현재 반복 변수 : {i}")