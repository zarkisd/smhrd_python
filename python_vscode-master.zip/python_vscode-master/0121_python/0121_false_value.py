print("# if 조건문 bool 판별")

if 0:
    print("true")
else:
    print("false")

if "":
    print("true")
else:
    print("false")