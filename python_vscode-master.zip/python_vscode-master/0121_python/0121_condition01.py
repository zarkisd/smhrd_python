number=input("정수 입력 > ")

num=int(number)
last_character=number[-1]
last_number=int(last_character)

if last_character in "02468":
    print("짝수")
else:
    print("홀수")

print()
print()
print()

if num%2==0:
    print("짝수")
else:
    print("홀수")
