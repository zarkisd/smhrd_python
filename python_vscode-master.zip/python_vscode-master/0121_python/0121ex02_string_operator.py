print("이름\t나이\t지역")
print("윤인성\t25\t강서구")

print("\\ \\ \\ \\")

