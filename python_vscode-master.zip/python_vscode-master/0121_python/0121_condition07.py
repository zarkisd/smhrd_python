score=float(input("학점 입력 > "))

if score ==4.5:
    print("god")
elif score >= 4.2:
    print("love of professor")
elif score >=3.5:
    print("guardian")
elif score >=2.8:
    print("just human")
elif score >=2.3:
    print("partisan")
elif score >= 1.75:
    print("play boy")
elif score >= 1.0:
    print("slave")
elif score >= 0.5:
    print("insect")
elif score >0:
    print("mitocondria")
else:
    print("revoultion")