dictionary={}

print(f"요소 추가 이전 : {dictionary}")

dictionary["name"]="new name"
dictionary["head"]="new spirit"
dictionary["body"]="healthy body"
print()
print(f"요소 추가 이후 : {dictionary}")