pi=3.14159265
r=10

print("원주율 = {}".format(pi))
print("반지름 = {}".format(r))
print("원의 둘레 = {}".format(2*pi*r))
print("원의 넓이 = {}".format(pi*(r**2)))

string_a=input("입력 A > ")
int_a=int(string_a)

string_b=input("입력 B > ")
int_b=int(string_b)

print("문자열 자료 : {}".format(string_a+string_b))
print("숫자 자료 : {}".format(int_a+int_b))

output_a=int("52")
output_b=float("52.273")

print(type(output_a), output_a)
print(type(output_b), output_b)