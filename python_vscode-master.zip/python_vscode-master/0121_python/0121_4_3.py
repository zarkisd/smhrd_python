#1
for i in range(4,6):
    print("{}".format(i), end=" ")
print()
for i in range(7,0,-1):
    print("{}".format(i), end=" ")
print()
for i in range(3,10,3):
    print("{}".format(i), end=" ")
print()
#2
key_list=["name", "hp", "mp", "lelve"]
value_list=["기사", 200, 30, 5]
character={}

for i in range(0,4):
    character[key_list[i]]=value_list[i]

print(character)
#3
limit=10000
i=1
sum_value=0
while True:
    sum_value+=i
    i+=1
    if sum_value > 10000:
        print(f"{i-1}을 더할 때 {limit}을 넘으며 그떄의 값은 {sum_value}입니다.")
        break

#4
max_value=0
a=0
b=0

for i in range(1,100):
    j=100-i
    if max_value<i*j:
        max_value=i*j
        a=i
        b=j

print(f"최대가 되는 경우 : {a}*{b}={max_value}")



