output_a="{:d}".format(52)

output_b="{:5d}".format(52)
output_c="{:10d}".format(52)

output_d="{:05d}".format(52)
output_e="{:05d}".format(-52)

print(output_a)
print(output_b)
print(output_c)
print(output_d)
print(output_e)

output_f="{:+d}".format(52)
output_g="{:+d}".format(-52)
output_h="{: d}".format(52)
output_i="{: d}".format(-52)

print(output_f)
print(output_g)
print(output_h)
print(output_i)

output_h="{:+5d}".format(52)
output_i="{:+5d}".format(-52)
output_j="{:=+5d}".format(52)
output_k="{:=+5d}".format(-52)
output_l="{:+05d}".format(52)
output_m="{:+05d}".format(-52)

print(output_h)
print(output_i)
print(output_j)
print(output_k)
print(output_l)
print(output_m)



