#import keyword
#print(keyword.kwlist)

print("#하나만 출력합니다")
print("Hello Python Programming...!!")
print()
print(10,20,30,40,50)
print("안녕하세요", "나는", "누구일까")
print()

print("확인 전용선")