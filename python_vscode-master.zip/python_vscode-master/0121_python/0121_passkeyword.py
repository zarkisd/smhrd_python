number=int(input("숫자 입력 > "))

if number>0:
    #미구현
    pass
else:
    #미구현
    pass

if number>0:
    #미구현
    raise NotImplementedError
else:
    #미구현
    raise NotImplementedError