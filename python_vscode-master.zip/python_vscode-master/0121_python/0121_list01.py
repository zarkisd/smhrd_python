list_a=[1,2,3]
list_b=[4,5,6]

print("#리스트")
print("list_a = {}".format(list_a))
print("list_b = {}".format(list_b))
print()

print("list_a + list_b = {}".format(list_a+list_b))
print("list_a *3 = {}".format(list_a*3))

print("len(list_a) = {}".format(len(list_a)))

list_a.append(4)
list_a.append(5)
print(list_a)
print()

list_a.insert(0,10)
print(list_a)

list_a.extend([4,5,6,7])
print(list_a)
#list_a+list_b 와 list_a.extend(list_b)는 기능은 같지만 과정이 다르다 (비파괴/파괴)
#인덱스로 제거하기 del, pop
# 둘다 인덱스
del list_a[1]
print("del list_a[1] : ",list_a)
list_a.pop(2)
print("list_a.pop(2) :  ",list_a)
#값은 remove
# 전체 싹 제거는 list_a.clear