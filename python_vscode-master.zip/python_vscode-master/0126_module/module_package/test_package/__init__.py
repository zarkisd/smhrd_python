__all__=["module_a","module_b"]

print("test_package를 읽어 들였습니다.")