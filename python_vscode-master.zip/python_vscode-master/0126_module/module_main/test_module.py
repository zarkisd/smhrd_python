print("# 모듈의 __name__ 출력하기")
print(__name__)
print()

#프로그램진입전을 엔트리 포인트 또는 메인
# 이러한 포인트 또는 메인에서 __name__은 __main__ 이다